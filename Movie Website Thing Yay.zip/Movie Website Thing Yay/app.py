from flask import Flask, render_template, request, jsonify, url_for

app = Flask(__name__)

@app.route("/")
def main():
    return render_template("Homepage.HTML")